%John C. Williams
%
%ChR2 model state variable derivates.
%O1 + O2 + C1 + C2 = 1
%
%Model of Channelrhodopsin-2 from:
%  Computational Optogenetics: Empirically-Derived Voltage- and 
%   Light-Sensitive Channelrhodopsin-2 Model
%Authors: 
%  John C. Williams, Jianjin Xu, Zhongju Lu, Aleksandra Klimas,
%   Christina M. Ambrosi, & Emilia Entcheva
%
% Cardiac Optogenetics and Optical Imaging Lab
%  Department of Biomedical Engineering, Stony Brook University
%  P.I.  Emilia Entcheva, PhD
%

function [out] = f_ChR2(O1,O2,C1,C2,p,irradiance,wavelength,V,T)
parameters = ChR2params(V,T);
hc = 1.986446E-25; %kg m^3/s^2
Ephoton = 1E9*hc/wavelength;  %J,  converted lambda from nm to m
if(irradiance > 0)
    logphi0 = log(1 + (irradiance/0.024));  %Unitless
else
    logphi0 = 0;    %Unitless
end;
e12 = parameters.e12dark + 0.005*logphi0; %ms^-1
e21 = parameters.e21dark + 0.004*logphi0; %ms^-1

flux = 1000*irradiance/Ephoton; %1/(s*m^2), converted irradiance from mW/mm^2 to W/m^2
F  = flux*parameters.sigma_retinal/(parameters.wloss*1000);  %ms^-1, convert F from 1/s to 1/ms
theta = 100*irradiance;
S0 = 0.5*(1 + tanh(120*(theta - 0.1)));  %Unitless
Fp = F*p;

dC1O1 = parameters.epsilon1*Fp*C1;
dO1C1 = parameters.Gd1*O1;
dO1O2 = e12*O1;
dO2O1 = e21*O2;
dO2C2 = parameters.Gd2*O2;
dC2O2 = parameters.epsilon2*Fp*C2;
dC2C1 = parameters.Gr*C2;
out.dp  =  (S0 - p)/parameters.tauChR2;
out.dC1  =  dC2C1 + dO1C1 - dC1O1;
out.dO1  =  dC1O1 + dO2O1 - dO1C1 - dO1O2;
out.dO2  =  dC2O2 + dO1O2 - dO2C2 - dO2O1;
out.dC2  =  dO2C2 - dC2O2 - dC2C1;
end