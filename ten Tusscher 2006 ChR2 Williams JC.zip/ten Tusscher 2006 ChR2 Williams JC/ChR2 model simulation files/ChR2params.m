%John C. Williams
%
%ChR2 model parameters.  Accepts voltage and temperature as parameters.
% Returns a struct of ChR2 model parameters.
%
%Model of Channelrhodopsin-2 from:
%  Computational Optogenetics: Empirically-Derived Voltage- and 
%   Light-Sensitive Channelrhodopsin-2 Model
%Authors: 
%  John C. Williams, Jianjin Xu, Zhongju Lu, Aleksandra Klimas,
%   Christina M. Ambrosi, & Emilia Entcheva
%
% Cardiac Optogenetics and Optical Imaging Lab
%  Department of Biomedical Engineering, Stony Brook University
%  P.I.  Emilia Entcheva, PhD
%
function [parameters] = ChR2params(V,T)
parameters.gamma = 0.1;
parameters.wloss = 1.3;
parameters.sigma_retinal = 12E-20; %m^2

parameters.e12dark = 0.011;  %ms^-1                               %Higher e12/e21 = higher (less negative) resting state, and vice versa
parameters.e21dark = 0.008;  %ms^-1
parameters.Gd1 = 0.075 + 0.043.*tanh((V+20)./-20);     %ms^-1                          %Steady to rest, faster at higher values
parameters.Gd2 = 0.05; %ms^-1                          %Steady to rest, trails more slowly at lower values
parameters.Gr = 0.0000434587*exp(-0.0211539274*V);      %ms^-1                         %Affects resting state (and recovery to C1 after stimulus)
parameters.gChR2 = 2.0/5;  %mS/cm^2                      %Scales current, increased to 2.0 from 0.75
parameters.tauChR2 = 1.3;  %ms                         %Increading moves dip rightward and slows recovery from steady state to resting
parameters.epsilon1 = 0.8535;                          %Larger value creates larger dip
parameters.epsilon2 = 0.14;                            %Smaller value crates higher steady state and longer time to steady state

parameters.E_ChR2 = 0;

%Q10 values for temperature dependence
Q10.Gd1         = 1.97;
Q10.Gd2         = 1.77;
Q10.epsilon1    = 1.46;
Q10.epsilon2    = 2.77;
Q10.Gr          = 2.56;
Q10.e12dark     = 1.1;
Q10.e21dark     = 1.95;

%Scale parameters with temperature using Q10
temperature = T - 273.15;   %convert from Kelvin to Celsius
parameters.Gd1      = parameters.Gd1*(Q10.Gd1^((temperature-22)/10));
parameters.Gd2      = parameters.Gd2*(Q10.Gd2^((temperature-22)/10));
parameters.e12dark  = parameters.e12dark*(Q10.e12dark^((temperature-22)/10));
parameters.e21dark  = parameters.e21dark*(Q10.e21dark^((temperature-22)/10));
parameters.Gr       = parameters.Gr*(Q10.Gr^((temperature-22)/10));
parameters.epsilon1 = parameters.epsilon1*(Q10.epsilon1^((temperature-22)/10));
parameters.epsilon2 = parameters.epsilon2*(Q10.epsilon2^((temperature-22)/10));

%Rectification curve-fit parameters:
    parameters.A = +10.6408;
    parameters.B = -14.6408;
    parameters.C = +42.7671;
end
