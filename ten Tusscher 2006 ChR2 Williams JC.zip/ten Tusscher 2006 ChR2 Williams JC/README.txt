ten Tusscher human ventricle cell model
Based on C code from 2006 Paper (Epicardial Cell):
  Ten Tusscher K.H. & Panfilov A.V. (2006).
  Alternans and spiral breakup in a human ventricular tissue model. 

 This model describes the voltage and currents in a human ventricular 
  myocite.
 Includes current from Channelrhodopsin-2 as described in:
  John C. Williams, Jianjin Xu, Zhongju Lu, Aleksandra Klimas,
   Christina M. Ambrosi, & Emilia Entcheva (2013)
  Computational Optogenetics: Empirically-Derived Voltage- and 
   Light-Sensitive Channelrhodopsin-2 Model

 Code maintained by: John C. Williams
   Contact: John.Williams.1@StonyBrook.edu for assistance, comments, etc.

 Cardiac Optogenetics and Optical Imaging Lab
  Department of Biomedical Engineering, Stony Brook University
  P.I.  Emilia Entcheva, PhD


To use:
Run MAIN_ten_Tusscher.m .  Simulation parameter (tend) and stimulation protocol are defined within this file.


Simulation parameters:

tend:		Simulation end time, ms


Stimulus parameters:

stim.delay:	delay before first electrical stimulus
stim.dur:	ms, electrical stimulus duration
stim.amp:	pA/pF, electrical stimulus amplitude (0 for off)
stim.number:	Number of electrical pulses (0 for off)
stim.interval:	interval bewteen electrical stimuli, ms

opt.delay:	interval bewteen optical stimuli, ms
opt.dur:	ms, optical stimulus duration
opt.irradiance:	ms, optical stimulus amplitude (irradiance, 0 for off)
opt.wavelength:	nm (Note: This model is designed for use at or around 470nm)
opt.number:	Number of optical pulses (0 for off)
opt.interval:	interval bewteen electrical stimuli, ms