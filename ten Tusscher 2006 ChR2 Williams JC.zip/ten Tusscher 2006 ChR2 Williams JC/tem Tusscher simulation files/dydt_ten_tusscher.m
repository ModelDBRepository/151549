function [deriv] = dydt_ten_tusscher(t,statevar,Istim,irradiance,wavelength)
%Differential equations for ten Tusscher 2006 human ventricular cell model.
%Model of Channelrhodopsin-2 from:
%  Computational Optogenetics: Empirically-Derived Voltage- and 
%   Light-Sensitive Channelrhodopsin-2 Model
%Authors: 
%  John C. Williams, Jianjin Xu, Zhongju Lu, Aleksandra Klimas,
%   Christina M. Ambrosi, & Emilia Entcheva
%
%Code maintained by: John C. Williams
%Cardiac Optogenetics and Optical Imaging Lab
%Department of Biomedical Engineering
%Stony Brook University
%P.I.  Emilia Entcheva, PhD
%

global R F T Ko Cm Csc Cao Nao Vc Vsr Vss Bufc Kbufc Bufsr Kbufsr Bufss ...
    Kbufss Vmaxup Kup Vrel k1_ k2_ k3 k4 EC maxsr minsr Vleak Vxfer 
global Gkr pKNa Gks GK1 Gto GNa GbNa KmK KmNa knak GCaL GbCa knaca ...
    KmNai KmCa ksat n GpCa KpCa GpK tau_m_vector tau_h_vector tau_index
statevarcell = num2cell(statevar) ;
[V,Cai,CaSR,CaSS,Nai,Ki,m,h,j,xr1,xr2,xs,r,s,d,f,f2,fCaSS,rr,C1,C2,O1,O2,p]= ...
    deal(statevarcell{:}) ;

ChR2parameters = ChR2params(V,T);

%% Reversal Potentials
Ek=(R*T)/F*(log((Ko/Ki)));
Ena=(R*T)/F*(log((Nao/Nai)));
Eks=(R*T)/F*(log((Ko+pKNa*Nao)/(Ki+pKNa*Nai)));
Eca=0.5*(R*T)/F*(log((Cao/Cai)));

%% Na+ Current
INa=GNa*m*m*m*h*j*(V-Ena);

%% Ca2+ L-type Current
ICaL=GCaL*d*f*f2*fCaSS*4*(V-15)*(F*F/(R*T))*(0.25*exp(2*(V-15)*F/(R*T))*CaSS-Cao)/(exp(2*(V-15)*F/(R*T))-1);

%% Transient Outward Current
Ito=Gto*r*s*(V-Ek);

%% Rapid Delayed Rectifier Current
IKr=Gkr*sqrt(Ko/5.4)*xr1*xr2*(V-Ek);

%% Slowed Delayed Rectifier Current
IKs=Gks*xs*xs*(V-Eks);

%% Inward Rectifier Current
a_k1=0.1/(1+exp(0.06*(V-Ek-200)));
b_k1=(3*exp(0.0002*(V-Ek+100))+exp(0.1*(V-Ek-10)))/(1+exp(-0.5*(V-Ek)));
xK1_inf=a_k1/(a_k1+b_k1);
IK1=GK1*xK1_inf*(V-Ek);

%% Na+/Ca2+ Exchanger Current
INaCa=knaca*(1/(KmNai*KmNai*KmNai+Nao*Nao*Nao))*(1/(KmCa+Cao))*(1/(1+ksat*exp((n-1)*V*F/(R*T))))*(exp(n*V*F/(R*T))*Nai*Nai*Nai*Cao-exp((n-1)*V*F/(R*T))*Nao*Nao*Nao*Cai*2.5);

%% Na+/K+ Pump Current
rec_iNaK=(1/(1+0.1245*exp(-0.1*V*F/(R*T))+0.0353*exp(-V*F/(R*T))));
INaK=knak*(Ko/(Ko+KmK))*(Nai/(Nai+KmNa))*rec_iNaK;

rec_ipK=1/(1+exp((25-V)/5.98));
IpCa=GpCa*Cai/(KpCa+Cai);
IpK=GpK*rec_ipK*(V-Ek);

%% Background Currents
IbNa=GbNa*(V-Ena);
IbCa=GbCa*(V-Eca);

%% ChR2 Current
G_ChR2 = ChR2parameters.gChR2/Csc;   % (mS/cm2) / (uF/cm2) = mS/uF
A = +10.6408;
B = -14.6408;
C = +42.7671;
% The nonlinear I/V characteristic of Channelrhodopsin-2 was fitted in
% part via direct scaling of the resulting current, i.e. by scaling the
% ChR2 conducting state (O1/O2) conductances.
IChR2 = G_ChR2.*((A+B*exp(-V/C))).*(O1 + ChR2parameters.gamma.*O2); %Current magnitude depends on fraction of ChR2 in states O1 and O2

%% Total Ion Current
Iion = IKr+IKs+IK1+Ito+INa+IbNa+ICaL+IbCa+INaK+INaCa+IpCa+IpK+IChR2;

dV=-(Iion+Istim);

%% CALCIUM DYNAMICS
kCaSR=maxsr-((maxsr-minsr)/(1+(EC/CaSR)*(EC/CaSR)));
k1=k1_/kCaSR;
k2=k2_*kCaSR;
drr=k4*(1-r)-k2*CaSS*rr;
OO=k1*CaSS*CaSS*rr/(k3+k1*CaSS*CaSS);

Irel=Vrel*OO*(CaSR-CaSS);
Ileak=Vleak*(CaSR-Cai);
Iup=Vmaxup/(1+((Kup*Kup)/(Cai*Cai)));
Ixfer=Vxfer*(CaSS-Cai);

CaCSQN=Bufsr*CaSR/(CaSR+Kbufsr);
dCaSR=(Iup-Irel-Ileak);
bjsr=Bufsr-CaCSQN-dCaSR-CaSR+Kbufsr;
cjsr=Kbufsr*(CaCSQN+dCaSR+CaSR);
CaSR=(sqrt(bjsr*bjsr+4*cjsr)-bjsr)/2;

CaSSBuf=Bufss*CaSS/(CaSS+Kbufss);
dCaSS=(-Ixfer*(Vc/Vss)+Irel*(Vsr/Vss)+(-ICaL/(2*Vss*F)*Cm));
bcss=Bufss-CaSSBuf-dCaSS-CaSS+Kbufss;
ccss=Kbufss*(CaSSBuf+dCaSS+CaSS);
CaSS=(sqrt(bcss*bcss+4*ccss)-bcss)/2;

CaBuf=Bufc*Cai/(Cai+Kbufc);
dCai=((-(IbCa+IpCa-2*INaCa)/(2*Vc*F)*Cm)-(Iup-Ileak)*(Vsr/Vc)+Ixfer);
bc=Bufc-CaBuf-dCai-Cai+Kbufc;
cc=Kbufc*(CaBuf+dCai+Cai);
Cai=(sqrt(bc*bc+4*cc)-bc)/2;

%% CONCENTRATION UPDATE
dNai=-(INa+IbNa+3*INaK+3*INaCa)/(Vc*F)*Cm;

dKi=-(Istim+IK1+Ito+IKr+IKs-2*INaK+IpK)/(Vc*F)*Cm;

%% Na+ CURRENT
a_m=1/(1+exp((-60-V)/5));
b_m=0.1/(1+exp((V+35)/5))+0.10/(1+exp((V-50)/200));
tau_m=a_m*b_m;
m_inf=1/((1+exp((-56.86-V)/9.03))*(1+exp((-56.86-V)/9.03)));

dm=(m_inf-m)/tau_m;

if (V>=-40)
    a_h1=0;
    b_h1=(0.77/(0.13*(1+exp(-(V+10.66)/11.1))));
    tau_h= 1.0/(a_h1+b_h1);
else
    a_h2=(0.057*exp(-(V+80)/6.8));
    b_h2=(2.7*exp(0.079*V)+(3.1e5)*exp(0.3485*V));
    tau_h=1.0/(a_h2+b_h2);
end
tau_h_vector(tau_index) = tau_h;
tau_m_vector(tau_index) = tau_m;
tau_index = tau_index + 1;
h_inf=1/((1+exp((V+71.55)/7.43))*(1+exp((V+71.55)/7.43)));
if(V>=-40)
    a_j1=0;
    b_j1=(0.6*exp((0.057)*V)/(1+exp(-0.1*(V+32))));
    tau_j= 1.0/(a_j1+b_j1);
else
    a_j2=(((-2.5428e4)*exp(0.2444*V)-(6.948e-6)*exp(-0.04391*V))*(V+37.78)/(1+exp(0.311*(V+79.23))));
    b_j2=(0.02424*exp(-0.01052*V)/(1+exp(-0.1378*(V+40.14))));
    tau_j= 1.0/(a_j2+b_j2);
end
j_inf=h_inf;

dh=(h_inf-h)/tau_h;
dj=(j_inf-j)/tau_j;

%% L-TYPE Ca2+ CURRENT
d_inf=1/(1+exp((-8-V)/7.5));
a_d=1.4/(1+exp((-35-V)/13))+0.25;
b_d=1.4/(1+exp((V+5)/5));
c_d=1/(1+exp((50-V)/20));
tau_d=a_d*b_d+c_d;

f_inf=1/(1+exp((V+20)/7));
a_f=1102.5*exp(-(V+27)*(V+27)/225);
b_f=200/(1+exp((13-V)/10));
c_f=(180/(1+exp((V+30)/10)))+20;
tau_f=a_f+b_f+c_f;

f2_inf=0.67/(1+exp((V+35)/7))+0.33;
a_f2=600*exp(-(V+25)*(V+25)/170);
b_f2=31/(1+exp((25-V)/10));
c_f2=16/(1+exp((V+30)/10));
tau_f2=a_f2+b_f2+c_f2;

fCaSS_inf=0.6/(1+(CaSS/0.05)*(CaSS/0.05))+0.4;
tau_fCaSS=80/(1+(CaSS/0.05)*(CaSS/0.05))+2;
     
dd=(d_inf-d)/tau_d;
df=(f_inf-f)/tau_f;
df2=(f2_inf-f2)/tau_f2;
dfCaSS=(fCaSS_inf-fCaSS)/tau_fCaSS;

%% TRANSIENT OUTWARD CURRENT
r_inf=1/(1+exp((20-V)/6));
s_inf=1/(1+exp((V+20)/5));
tau_r=9.5*exp(-(V+40)*(V+40)/1800)+0.8;
tau_s=85*exp(-(V+45)*(V+45)/320)+5/(1+exp((V-20)/5))+3;

dr=(r_inf-r)/tau_r;
ds=(s_inf-s)/tau_s;

%% SLOW DELAYED RECTIFIER CURRENT
xs_inf=1/(1+exp((-5-V)/14));
a_xs=(1400/(sqrt(1+exp((5-V)/6))));
b_xs=(1/(1+exp((V-35)/15)));
tau_xs=a_xs*b_xs+80;

dxs=(xs_inf-xs)/tau_xs;

%% RAPID DELAYED RECTIFIER CURRENT
xr1_inf=1/(1+exp((-26-V)/7));
a_xr1=450/(1+exp((-45-V)/10));
b_xr1=6/(1+exp((V-(-30))/11.5));
tau_xr1=a_xr1*b_xr1;
xr2_inf=1/(1+exp((V-(-88))/24));
a_xr2=3/(1+exp((-60-V)/20));
b_xr2=1.12/(1+exp((V-60)/20));
tau_xr2=a_xr2*b_xr2;

dxr1=(xr1_inf-xr1)/tau_xr1;
dxr2=(xr2_inf-xr2)/tau_xr2;

%% ChR2 CURRENT, 2013 
% John C. Williams
% Cardiac Optogenetics and Optical Imaging Lab
% P.I.  Emilia Entcheva, PhD
% Department of Biomedical Engineering
% Stony Brook University
% Stony Brook, NY
ChR2out = f_ChR2(O1,O2,C1,C2,p,irradiance,wavelength,V,T);
dC1 = ChR2out.dC1;
dC2 = ChR2out.dC2;
dO1 = ChR2out.dO1;
dO2 = ChR2out.dO2;
dp = ChR2out.dp;

deriv = [dV;dCai;dCaSR;dCaSS;dNai;dKi;dm;dh;dj;dxr1;dxr2;dxs;dr;ds; ...
  dd;df;df2;dfCaSS;drr;dC1;dC2;dO1;dO2;dp] ;

return
