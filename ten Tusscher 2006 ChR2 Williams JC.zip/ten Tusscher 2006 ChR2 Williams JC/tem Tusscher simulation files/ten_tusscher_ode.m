function [out] = ten_tusscher_ode(stim,opt,tend)
%% 2006 ten Tusscher human ventricular tissue model
% Based on C code
%
%Simulation of the ten Tusscher ventricular myocite
% using passed stimulation protocol, model parameters, voltage, and 
% simulation end time.
%Returns a struct (out) of model time, Voltage, and currents.
%
%Model of Channelrhodopsin-2 from:
%  Computational Optogenetics: Empirically-Derived Voltage- and 
%   Light-Sensitive Channelrhodopsin-2 Model
%Authors: 
%  John C. Williams, Jianjin Xu, Zhongju Lu, Aleksandra Klimas,
%   Christina M. Ambrosi, & Emilia Entcheva
%Code maintained by: John C. Williams
%
%Cardiac Optogenetics and Optical Imaging Lab
%Department of Biomedical Engineering
%Stony Brook University
%P.I.  Emilia Entcheva, PhD
%

%% PARAMETERS
global R F T Ko Cm Csc Cao Nao Vc Vsr Vss Bufc Kbufc Bufsr Kbufsr Bufss ...
    Kbufss Vmaxup Kup Vrel k1_ k2_ k3 k4 EC maxsr minsr Vleak Vxfer 
global Gkr pKNa Gks GK1 Gto GNa GbNa KmK KmNa knak GCaL GbCa knaca ...
    KmNai KmCa ksat n GpCa KpCa GpK
pause(0.01)
R=8314.472;
F=96485.3415;
T=310.0;
Cm=0.185;
Csc=1.0;
Ko=5.4;
Cao=2.0;
Nao=140.0;
Vc=0.016404;
Vsr=0.001094;
Vss=0.00005468;
Bufc=0.2;
Kbufc=0.001;
Bufsr=10.;
Kbufsr=0.3;
Bufss=0.4;
Kbufss=0.00025;
Vmaxup=0.006375;
Kup=0.00025;
Vrel=0.102;
k1_=0.15;
k2_=0.045;
k3=0.060;
k4=0.005;
EC=1.5;
maxsr=2.5;
minsr=1.;
Vleak=0.00036;
Vxfer=0.0038;
Gkr=0.153;
pKNa=0.03;
Gks=0.392;
GK1=5.405;
Gto=0.294;
GNa=14.838;
GbNa=0.00029;
KmK=1.0;
KmNa=40.0;
knak=2.724;
GCaL=0.00003980;  
GbCa=0.000592;
knaca=1000;
KmNai=87.5;
KmCa=1.38;
ksat=0.1;
n=0.35;
GpCa=0.1238;
KpCa=0.0005;
GpK=0.0146;

intervals = simIntervals(stim,opt,tend);
simints = size(intervals,1);

%% INITIAL CONDITIONS

V=-85.8;
Cai=0.00007;
CaSR=1.3;
CaSS=0.00007;
Nai=7.67;
Ki=138.3;
m=0.;
h=0.75;
j=0.75;
xr1=0.;
xr2=1.;
xs=0.;
r=0.;
s=1.;
d=0.;
f=1.;
f2=1.;
fCaSS=1.;
rr=1.;
C1=1;
C2=0;
O1=0;
O2=0;
p=0;

statevar_i = [V;Cai;CaSR;CaSS;Nai;Ki;m;h;j;xr1;xr2;xs;r;s;d;f;f2;...
    fCaSS;rr;C1;C2;O1;O2;p;];

options = odeset('AbsTol',1e-10,'RelTol',1e-10);
%options = odeset('AbsTol',eps,'RelTol',eps,'Refine',4);
ssbefore=1;

if (ssbefore)
    pause(0.01)
  [post,posstatevars] = ode15s(@dydt_ten_tusscher,[0,2e6],statevar_i,options,0,0,opt.wavelength) ;
  statevar_i = posstatevars(end,:) ;
end
 
options = odeset('AbsTol',1e-10,'RelTol',1e-10,'MaxStep',0.1);
t = 0 ;
statevars = statevar_i ;
for i=1:simints
    pause(0.01)
    [post,posstatevars] = ode15s(@dydt_ten_tusscher,intervals(i,1:2),statevar_i,options,intervals(i,3),intervals(i,4),opt.wavelength) ;
    t = [t;post(2:end)] ;
    statevars = [statevars;posstatevars(2:end,:)] ;
    statevar_i = posstatevars(end,:) ;
end
pause(0.01)
outputcell = num2cell(statevars,1) ;
nvariables = length(outputcell) ;

[V,Cai,CaSR,CaSS,Nai,Ki,m,h,j,xr1,xr2,xs,r,s,d,f,f2,fCaSS,rr,C1,C2,O1,O2,p]= ...
  deal(outputcell{:}) ;

%% Reversal Potentials
Ek=(R*T)/F*(log((Ko./Ki)));
Ena=(R*T)/F*(log((Nao./Nai)));
Eks=(R*T)/F*(log((Ko+pKNa*Nao)./(Ki+pKNa*Nai)));
Eca=0.5*(R*T)/F*(log((Cao./Cai)));

%% Na+ Current
INa=GNa*m.*m.*m.*h.*j.*(V-Ena);
conductance.INa = GNa*m.*m.*m.*h.*j;

%% Ca2+ L-type Current
ICaL=GCaL*d.*f.*f2.*fCaSS.*4.*(V-15).*(F*F/(R*T)).*(0.25*exp(2*(V-15).*F/(R*T)).*CaSS-Cao)./(exp(2*(V-15).*F/(R*T))-1);
conductance.ICaL = GCaL*d.*f.*f2.*fCaSS;

%% Transient Outward Current
Ito=Gto*r.*s.*(V-Ek);
conductance.Ito = Gto*r.*s;

%% Rapid Delayed Rectifier Current
IKr=Gkr*sqrt(Ko./5.4)*xr1.*xr2.*(V-Ek);
conductance.IKr = Gkr*sqrt(Ko./5.4)*xr1.*xr2;

%% Slowed Delayed Rectifier Current
IKs=Gks*xs.*xs.*(V-Eks);
conductance.IKs = Gks*xs.*xs;

%% Inward Rectifier Current
a_k1=0.1./(1+exp(0.06*(V-Ek-200)));
b_k1=(3*exp(0.0002*(V-Ek+100))+exp(0.1*(V-Ek-10)))./(1+exp(-0.5*(V-Ek)));
xK1_inf=a_k1./(a_k1+b_k1);
IK1 = GK1*xK1_inf.*(V-Ek);
conductance.IK1 = GK1*xK1_inf;

%% Na+/Ca2+ Exchanger Current
INaCa=knaca.*(1./(KmNai.*KmNai.*KmNai+Nao*Nao*Nao)).*(1./(KmCa+Cao)).*(1./(1+ksat*exp((n-1)*V*F/(R*T)))).*(exp(n*V*F/(R*T)).*Nai.*Nai.*Nai.*Cao-exp((n-1)*V*F/(R*T))*Nao.*Nao.*Nao.*Cai.*2.5);

%% Na+/K+ Pump Current
rec_iNaK=(1./(1+0.1245*exp(-0.1*V*F/(R*T))+0.0353*exp(-V*F/(R*T))));
INaK=knak*(Ko./(Ko+KmK)).*(Nai./(Nai+KmNa)).*rec_iNaK;

rec_ipK=1./(1+exp((25-V)/5.98));
IpCa=GpCa*Cai./(KpCa+Cai);
IpK=GpK*rec_ipK.*(V-Ek);
conductance.IpK = GpK*rec_ipK;

%% Background Currents
IbNa=GbNa*(V-Ena);
conductance.IbNa = GbNa;
IbCa=GbCa*(V-Eca);
conductance.IbCa = GbCa;

%% ChR2 Current
ChR2parameters = ChR2params(V,T);
G_ChR2 = ChR2parameters.gChR2/Csc;   % (mS/cm2) / (uF/cm2) = mS/uF
A = ChR2parameters.A;
B = ChR2parameters.B;
C = ChR2parameters.C;
% The nonlinear I/V characteristic of Channelrhodopsin-2 was fitted in
% part via direct scaling of the resulting current, i.e. by scaling the
% ChR2 conducting state (O1/O2) conductances.
IChR2 = G_ChR2.*((A+B*exp(-V/C))).*(O1 + ChR2parameters.gamma.*O2); %Current magnitude depends on fraction of ChR2 in states O1 and O2
%% Total Ion Current
Iion = IKr+IKs+IK1+Ito+INa+IbNa+ICaL+IbCa+INaK+INaCa+IpCa+IpK+IChR2;
AbsIion = abs(IKr)+abs(IKs)+abs(IK1)+abs(Ito)+abs(INa)+abs(IbNa)+abs(ICaL)+abs(IbCa)+abs(INaK)+abs(INaCa)+abs(IpCa)+abs(IpK)+abs(IChR2);
conductance.pF = conductance.IKr + conductance.IKs + conductance.IK1 + ...
    conductance.Ito + conductance.INa + conductance.IbNa + conductance.ICaL ...
    + conductance.IbCa + conductance.IpK;  %Ignoring IChR2, nS/pF
conductance.Potassium = 185*(conductance.IKr + conductance.IKs + conductance.IK1 ...
    + conductance.Ito + conductance.IpK); %nS 
conductance.Sodium = 185*(conductance.INa + conductance.IbNa); %nS
conductance.Calcium = (conductance.ICaL + conductance.IbCa); %nS
conductance.total = conductance.pF*185; %nS


out.t = t;
out.V = V;
out.INa=INa;
out.ICaL=ICaL;
out.Ito=Ito;
out.IKr=IKr;
out.IKs=IKs;
out.IK1=IK1;
out.INaCa=INaCa;
out.INaK=INaK;
out.IpCa=IpCa;
out.IpK=IpK;
out.IbNa=IbNa;
out.IbCa=IbCa;
out.IChR2=IChR2;
out.O1 = O1;
out.O2 = O2;
out.C1 = C1;
out.C2 = C2;
%Other metrics:
out.Iion = Iion;
out.conductance = conductance;
out.resistance = 1000./(out.conductance.total); %MOhm
out.AbsIion = AbsIion; 
out.admittance = AbsIion./abs(V);
out.impedance = abs(V)./AbsIion;
pause(0.01)
end