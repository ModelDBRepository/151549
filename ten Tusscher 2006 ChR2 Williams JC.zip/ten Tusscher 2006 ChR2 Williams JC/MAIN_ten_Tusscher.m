%% ten Tusscher human ventricle cell model
% Based on C code from 2006 Paper (Epicardial Cell):
%  Ten Tusscher K.H. & Panfilov A.V. (2006).
%  Alternans and spiral breakup in a human ventricular tissue model. 
%
% This model describes the voltage and currents in a human ventricular 
%  myocite.
% Includes current from Channelrhodopsin-2 as described in:
%  John C. Williams, Jianjin Xu, Zhongju Lu, Aleksandra Klimas,
%   Christina M. Ambrosi, & Emilia Entcheva (2013)
%  Computational Optogenetics: Empirically-Derived Voltage- and 
%   Light-Sensitive Channelrhodopsin-2 Model
%
% Code maintained by: John C. Williams
%  Contact: John.Williams.1@StonyBrook.edu for assistance, comments, etc.
%
% Cardiac Optogenetics and Optical Imaging Lab
%  Department of Biomedical Engineering, Stony Brook University
%  P.I.  Emilia Entcheva, PhD
%
%%
close all
clearvars

addpath('.\tem Tusscher simulation files\')
addpath('.\ChR2 model simulation files\')
addpath('.\Other required functions\')
pause(0.1)


%%  End time
tend = 500;  %Simulation end time, ms

%% Electrical Stimulation protocol
stim.delay = 10;                %ms, delay before first electrical stimulus
stim.dur = 5;                   %ms, electrical stimulus duration
stim.amp = 0;                   %pA/pF, electrical stimulus amplitude (0 for off)
stim.number = 0;                %Number of electrical pulses (0 for off)
stim.interval = tend+1 ;        %interval bewteen electrical stimuli, ms
%  Note: interval between stimuli is time between the end of stimulus n and
%   the beginning of stimulus n+1

%% Optical stimulation protocol
opt.delay = 10;                 %interval bewteen optical stimuli, ms
opt.dur = 10;                   %ms, optical stimulus duration
opt.irradiance = 1.0;           %ms, optical stimulus amplitude (irradiance, 0 for off)
opt.number = 1;                 %Number of optical pulses (0 for off)
opt.wavelength = 470;           %nm (Note: This model is designed for use at or around 470nm)
opt.interval = tend;            %interval bewteen electrical stimuli, ms
%  Note: interval between stimuli is time between the end of stimulus n and
%   the beginning of stimulus n+1

%% Simulation
pause(0.1)
out = ten_tusscher_ode(stim,opt,tend);
pause(0.1)

%% Plot
figure
plot(out.t,out.V)
xlabel('Time (ms)')
ylabel('Voltage (mV)')
title(['Irradiance: ',num2str(opt.irradiance),'mW/mm^2  Wavelength:',num2str(opt.wavelength),'nm  Duration: ',num2str(opt.dur),'ms.   Begins at t=',num2str(opt.delay),'ms'])

figure
hold on
plot(out.t,out.IKr,'b')
plot(out.t,out.IKs,'r')
plot(out.t,out.IK1,'c')
plot(out.t,out.Ito,'g')
plot(out.t,out.IpK,'m')
plot(out.t,out.INaK,'y')
plot(out.t,out.IpCa,'k')
legend('I_K_r','I_K_s','I_K_1','I_t_o','I_p_K','I_N_a_K','I_p_C_a')
xlabel('Time (ms)')
ylabel('Current(pA/pF)')
title(['Irradiance: ',num2str(opt.irradiance),'mW/mm^2  Wavelength:',num2str(opt.wavelength),'nm  Duration: ',num2str(opt.dur),'ms.   Begins at t=',num2str(opt.delay),'ms'])

figure
hold on
plot(out.t,0.1*out.INa,'b')  %NOTE: INa scaled by 0.1
plot(out.t,out.ICaL,'g')
plot(out.t,out.INaCa,'m')
plot(out.t, out.IChR2,'k')
legend('I_N_a*0.1','I_C_a_L','I_N_a_C_a','I_C_h_R_2')
xlabel('Time (ms)')
ylabel('Current(pA/pF)')
title(['Irradiance: ',num2str(opt.irradiance),'mW/mm^2  Wavelength:',num2str(opt.wavelength),'nm  Duration: ',num2str(opt.dur),'ms.   Begins at t=',num2str(opt.delay),'ms'])

figure
plot(out.t,out.IChR2)%,'b','linewidth',2)
legend('I_C_h_R_2')
xlabel('Time (ms)')
ylabel('Current(pA/pF)')
xlim([0 400])
title(['Irradiance: ',num2str(opt.irradiance),'mW/mm^2  Wavelength:',num2str(opt.wavelength),'nm  Duration: ',num2str(opt.dur),'ms.   Begins at t=',num2str(opt.delay),'ms'])
grid on
