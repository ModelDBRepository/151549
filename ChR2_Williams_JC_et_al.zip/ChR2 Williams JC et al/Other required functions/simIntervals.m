%Simulation intervals generator
%  Author: John C. Williams
%Cardiac Optogenetics and Optical Imaging Lab
%  Department of Biomedical Engineering, Stony Brook University
%  Stony Brook, NY
%  P.I.  Emilia Entcheva, PhD
%Accepts three parameters: 2D array of electrical stimulus (time and magnitude),
%    2D array or optical stimulus, and the simulation end time.
%Returns a matrix of combined optical and electrical stimulus intervals.
function [intervals] = simIntervals(stim,opt,tend)
stimTimes = simtimes(tend,stim.interval,stim.delay,stim.dur,stim.amp);
optTimes = simtimes(tend,opt.interval,opt.delay,opt.dur,opt.irradiance);

totalIntervals = optTimes.numIntervals + stimTimes.numIntervals;
timeList = zeros(totalIntervals,1);
timeList(2:1+optTimes.numIntervals) = optTimes.intervals(:,2);  %%We can skip time = 0, so we only take the right side
timeList(2+optTimes.numIntervals:totalIntervals) = stimTimes.intervals(1:end-1,2);  %%We don't need tend
timeList = timeList(timeList(:)<=tend); %Filter out times after tend, probably unnecessary.
timeList = unique(timeList);  %Remove duplicates
timeList = sort(timeList);  %Sort
totalIntervals = length(timeList) - 1;
intervals = zeros(totalIntervals,4);
intervals(:,1) = timeList(1:end-1);  %Starting times
intervals(:,2) = timeList(2:end);  %Ending times
% Now to fill in the stimulation details:
stimIndex = 1;
optIndex = 1;
numStims = 0;
numOpts = 0;

for j=1:totalIntervals
    while(stimTimes.intervals(stimIndex,1) < intervals(j,1) && stimTimes.intervals(stimIndex,2) < intervals(j,2))
        stimIndex = stimIndex + 1;
    end
    while(optTimes.intervals(optIndex,1) < intervals(j,1) && optTimes.intervals(optIndex,2) < intervals(j,2))
        optIndex = optIndex + 1;
    end
    if (numStims < stim.number)
        intervals(j,3) = -stimTimes.stim(stimIndex);
    end
    if (numOpts < opt.number)
        intervals(j,4) = optTimes.stim(optIndex);
    end
    if (j > 1)
        if (intervals(j-1,3) ~= 0 && intervals(j,3) == 0)
            numStims = numStims + 1;
        end
        if (intervals(j-1,4) ~= 0 && intervals(j,4) == 0)
            numOpts = numOpts + 1;
        end
    end
end

    function [simtimes] = simtimes(tend,stiminterval,stimdelay,stimdur,stimamp)
        numStimStarts = 0;
        numStimEnds = 0;
        numTimes = 1;  %Captures tend
        time = stimdelay;
        if (time > 0)
            numTimes = numTimes + 1;    %Captures the starting 0 if the first stimulation is not at t=0
        end
        isABeginning = true;
        while (time < tend)
            if (isABeginning)
                numStimStarts = numStimStarts + 1;
                time = time + stimdur;
            else
                numStimEnds = numStimEnds + 1;
                time = time + stiminterval;
            end
            isABeginning = ~isABeginning;
        end
        numTimes = numTimes + numStimStarts + numStimEnds; %0 -- start -- end -- start -- end -- tend
        timeMarkers = zeros(numTimes,1);
        simtimes.stim = zeros(numTimes-1,1);
        index = 2;
        if (stimdelay > 0)
            timeMarkers(index) = stimdelay;
            index = index + 1;
        end
        stimActive = true;  %t=stimdelay, stimulus begins
        for index=index:numTimes-1
            if (stimActive)
                timeMarkers(index) = timeMarkers(index-1) + stimdur;
                simtimes.stim(index-1) = stimamp;
            else
                timeMarkers(index) = timeMarkers(index-1) + stiminterval;
            end
            stimActive = ~stimActive;
        end
        if(stimActive)
            simtimes.stim(numTimes - 1) = stimamp;
        end
        timeMarkers(numTimes) = tend;
        simtimes.intervals = zeros(numTimes-1,2);
        simtimes.numIntervals = numTimes - 1;
        for i=1:simtimes.numIntervals
            simtimes.intervals(i,1) = timeMarkers(i);
            simtimes.intervals(i,2) = timeMarkers(i+1);
        end
        i = 1;
        while (i <= simtimes.numIntervals)
            if (simtimes.intervals(i,1) == simtimes.intervals(i,2))
                simtimes.intervals(i,:) = [];
                simtimes.stim(i) = [];
                simtimes.numIntervals = simtimes.numIntervals - 1;
            else
                i = i + 1;
            end
        end
        
    end
end

