%
%This model describes current from Channelrhodopsin-2 as described in:
%  Computational Optogenetics: Empirically-Derived Voltage- and 
%   Light-Sensitive Channelrhodopsin-2 Model
%Authors: 
%  John C. Williams, Jianjin Xu, Zhongju Lu, Aleksandra Klimas,
%   Christina M. Ambrosi, & Emilia Entcheva
% Special thanks to Matthew Epstein & Keith Arora-Williams.
%
%Describes: 
%  Current from ChR2 variant H134R under voltage-clamp conditions
%   based on experimental data (Cardiac Cell Engineering Laboratory, 
%   Stony Brook University) with voltage-, irradiance-, and 
%   temperature-dependence.
%
%Code maintained by: John C. Williams
%  Contact: John.Williams.1@StonyBrook.edu for assistance, comments, or
%    just to let us know you're using this code!
%
%Cardiac Optogenetics and Optical Imaging Lab
%  Department of Biomedical Engineering, Stony Brook University
%  P.I.  Emilia Entcheva, PhD
%
%                   Cheers!
%

clearvars
close all
addpath('.\ChR2 simulation files\')
addpath('.\Other required functions\')

pause(0.1)

tend = 500;                     % Simulation end time, ms
temperature = 22;               % degrees C
V = -80;                        % Cell voltage, mV

%Optical stimulation protocol:
opt.interval = 1000;    %ms, interval between optical stimuli.
%  Note: interval between stimuli is time between the end of stimulus n and
%   the beginning of stimulus n+1
opt.delay = 10;         %ms, delay before first stimulus
opt.dur = 100;          %ms, stimulus duration
opt.irradiance = 1.0;   %mW/mm2, stimulus irradiance.
opt.number = 1;         %number of stimuli.
opt.lambda = 470;       %nm, wavelength.
%(Note: This model is designed for stimuli at or around 470nm)

%Get parameters:
parameters = ChR2_Parameters(V,temperature);

%Run simulation using desired protocol and parameters:
out = ChR2_Simulation(opt,parameters,V,tend);

pause(0.1)
%Plot figure
figure
plot(out.t,out.IChR2,'linewidth',2)                     %Plot model output
xlabel('Time (ms)')
ylabel('Current (pA/pF)')
title([num2str(V),' mV,  ',num2str(opt.irradiance),' mW/mm^2,  ', ...
    num2str(opt.dur),' ms,  ', num2str(temperature),'�C'])
pause(0.1)  %Pausing is to allow the MATLAB GUI to update, 
            %  likely unnecessary.
