%Simulation of ChR2 using passed stimulation protocol, model parameters,
%voltage, and simulation end time.
%Returns a struct of model state vectors (C1,C2,O1,O1,p,t,IChR2)
%Model of Channelrhodopsin-2 from:
%  Computational Optogenetics: Empirically-Derived Voltage- and 
%   Light-Sensitive Channelrhodopsin-2 Model
%Authors: 
%  John C. Williams, Jianjin Xu, Zhongju Lu, Aleksandra Klimas,
%   Christina M. Ambrosi, & Emilia Entcheva
%Code maintained by: John C. Williams
%P.I.  Emilia Entcheva, PhD
function [states] = ChR2_Simulation(optStim,parameters,V,tend)
%G_ChR2 in units of:  mS/uF

%Electrical stimulus.  This is not used here, but is maintained for
%cross-compatibility with accessory functions used in cellular models.
stim.interval = 1000 ;      % interval bewteen stimuli, ms
stim.delay = 0 ;
stim.dur = 10 ;
stim.amp = 0 ;  %disabled
stim.number = 0;

%Initial states.
t = 0 ;  %Time = 0
C1 = 1;  %Closed, dark-adapted
C2 = 0;  %Closed, light-adapted
O1 = 0;  %Open, dark-adapted
O2 = 0;  %Open, light-adapted
p = 0;   %Activation delay

%Initial calculations (Nikolic, 2009):
intervals = simIntervals(stim,optStim,tend);    %Generate simulation intervals
simints = size(intervals,1);                    %Determine number of intervals
statevar_i = [C1;C2;O1;O2;p];                   %Create vector of state variable initial states
options = odeset('AbsTol',1e-10,'RelTol',1e-10,'MaxStep',0.1);  %Configure ode solver tolerances
statevars = statevar_i' ;                       %Transpose vector

%This uses MATLAB's differential equation solver, ode15s, to integrate the
%system of differential equations contained in the file, 'ChR2_dydt.m'.
%This is an alternative to the forward euler method previously used.  All
%differential equations can be found in ChR2_dydt.
for i=1:simints
    [post,posstatevars] = ode15s(@ChR2_dydt,intervals(i,1:2),statevar_i,options,V,intervals(i,3),intervals(i,4),optStim.lambda,parameters);  %Integrate using MATLAB differential equation solver ode15s
    t = [t;post(2:end)] ;
    statevars = [statevars;posstatevars(2:end,:)] ; %Concatenate vector of state variable states
    statevar_i = posstatevars(end,:) ;
end
outputcell = num2cell(statevars,1) ;  %Make cell of ChR2 states
nvariables = length(outputcell) ;

[C1,C2,O1,O2,p] = deal(outputcell{:}) ; %Deal ChR2 state vectors to appropriate variables (also vectors).


%% Calculate current
A = +10.6408;
B = -14.6408;
C = +42.7671;
% The nonlinear I/V characteristic of Channelrhodopsin-2 was fitted in
% part via direct scaling of the resulting current, i.e. by scaling the
% ChR2 conducting state (O1/O2) conductances.
I_ChR2 = parameters.G_ChR2.*((A+B*exp(-V/C))).*(O1 + parameters.gamma.*O2); %Current magnitude depends on fraction of ChR2 in states O1 and O2

%Put model outputs into structure:
states.p = p;
states.t = t;
states.C1 = C1;
states.C2 = C2;
states.O1 = O1;
states.O2 = O2;
states.IChR2 = I_ChR2;
end
