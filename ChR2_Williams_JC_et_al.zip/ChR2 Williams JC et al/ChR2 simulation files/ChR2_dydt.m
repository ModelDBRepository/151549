%Differential equations for Channelrhodopsin-2 model.
%Model of Channelrhodopsin-2 from:
%  Computational Optogenetics: Empirically-Derived Voltage- and 
%   Light-Sensitive Channelrhodopsin-2 Model
%Authors: 
%  John C. Williams, Jianjin Xu, Zhongju Lu, Aleksandra Klimas,
%   Christina M. Ambrosi, & Emilia Entcheva
%Code maintained by: John C. Williams
%P.I.  Emilia Entcheva, PhD
function [derivatives] = ChR2_dydt(t,statevar,V,Vclamp,Irradiance,wavelength,parameters)

hc = 1.986446E-25; %kg m^3/s^2

statevarcell = num2cell(statevar) ;
[C1,C2,O1,O2,p]= ...
    deal(statevarcell{:}) ;

Ephoton = 1E9*hc/wavelength;  %J,  converted lambda from nm to m
if(Irradiance > 0)
    logphi0 = log(1 + (Irradiance/0.024));  %Unitless
else
    logphi0 = 0;    %Unitless
end;
e12 = parameters.e12dark + 0.005*logphi0; %ms^-1
e21 = parameters.e21dark + 0.004*logphi0; %ms^-1

flux = 1000*Irradiance/Ephoton; %1/(s*m^2), converted irradiance from mW/mm^2 to W/m^2
F  = flux*parameters.sigma_retinal/(parameters.wloss*1000);  %ms^-1, convert F from 1/s to 1/ms
% if(F > 0)
%     F = F
%     flux = flux
% end
theta = 100*Irradiance;
S0 = 0.5*(1 + tanh(120*(theta - 0.1)));  %Unitless
Fp = F*p;

dp  =  (S0 - p)/parameters.tauChR2;
dC1O1 = parameters.epsilon1*Fp*C1;
dO1C1 = parameters.Gd1*O1;
dO1O2 = e12*O1;
dO2O1 = e21*O2;
dO2C2 = parameters.Gd2*O2;
dC2O2 = parameters.epsilon2*Fp*C2;
dC2C1 = parameters.Gr*C2;
dC1  =  dC2C1 + dO1C1 - dC1O1;
dO1  =  dC1O1 + dO2O1 - dO1C1 - dO1O2;
dO2  =  dC2O2 + dO1O2 - dO2C2 - dO2O1;
dC2  =  dO2C2 - dC2O2 - dC2C1;
%Arrange derivatives into a vector
derivatives = [dC1;dC2;dO1;dO2;dp];
end
