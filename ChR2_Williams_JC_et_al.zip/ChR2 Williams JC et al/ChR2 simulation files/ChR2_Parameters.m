%Simulation of ChR2 using passed stimulation protocol, model parameters,
%voltage, and simulation end time.
%Returns a struct of model state vectors (C1,C2,O1,O1,p,t,IChR2)
%Model of Channelrhodopsin-2 from:
%  Computational Optogenetics: Empirically-Derived Voltage- and 
%   Light-Sensitive Channelrhodopsin-2 Model
%Authors: 
%  John C. Williams, Jianjin Xu, Zhongju Lu, Aleksandra Klimas,
%   Christina M. Ambrosi, & Emilia Entcheva
%Code maintained by: John C. Williams
%P.I.  Emilia Entcheva, PhD
function [parameters] = ChR2_Parameters(V,temperature)
%Parameters:
Cm = 1;                       % Membrane capacitance per unit area, uF/cm^2
%Parameters from Nicolic et al., 2008, Fig. 9
%Observed from: light intensity: 0.65 mW/mm, 470 nm wavelength, V = -70 mV:
parameters.gamma = 0.1;
parameters.wloss = 1.3;
parameters.epsilon2 = 0.14;

%Parameters Grossman et al., 2011, Figure 2:
parameters.e12dark = 0.011;  %ms^-1
parameters.e21dark = 0.008;  %ms^-1
parameters.Gd2 = 0.05;       %ms^-1
parameters.tauChR2 = 1.3;    %ms

parameters.epsilon2 = 0.14;

%Parameters from Talathi et al., 2010, Table 2:
parameters.epsilon1 = 0.8535;

%Retinal cross-sectional area: Increased from 1.2E-20 by a factor of 10:
parameters.sigma_retinal = 12E-20;  %m^2
%Reduced maximum conductance by a factor of 5.  In cellular models, this
%corresponds to expression levels, etc.:
parameters.gChR2 = 2.0/5;           %mS/cm^2
parameters.G_ChR2 = parameters.gChR2/Cm;     % (mS/cm2) / (uF/cm2) = mS/uF
%Recovery rate (C2-->C1).  Fit to experimental data:
parameters.Gr = 0.0000434587*exp(-0.0211539274*V); %ms^-1
%Dark-adapted deactivation rate.  Voltage dependence introduced to modulate
%kinetics across voltages.
parameters.Gd1 = 0.075 + 0.043.*tanh((V+20)./-20);


%Q10 values for temperature dependence
Q10.Gd1         = 1.97;
Q10.Gd2         = 1.77;
Q10.epsilon1    = 1.46;
Q10.epsilon2    = 2.77;
Q10.Gr          = 2.56;
Q10.e12dark     = 1.1;
Q10.e21dark     = 1.95;

%Scale parameters with temperature using Q10
parameters.Gd1      = parameters.Gd1*(Q10.Gd1^((temperature-22)/10));
parameters.Gd2      = parameters.Gd2*(Q10.Gd2^((temperature-22)/10));
parameters.e12dark  = parameters.e12dark*(Q10.e12dark^((temperature-22)/10));
parameters.e21dark  = parameters.e21dark*(Q10.e21dark^((temperature-22)/10));
parameters.Gr       = parameters.Gr*(Q10.Gr^((temperature-22)/10));
parameters.epsilon1 = parameters.epsilon1*(Q10.epsilon1^((temperature-22)/10));
parameters.epsilon2 = parameters.epsilon2*(Q10.epsilon2^((temperature-22)/10));
end
