This model describes current from Channelrhodopsin-2 as described in:
  Computational Optogenetics: Empirically-Derived Voltage- and 
   Light-Sensitive Channelrhodopsin-2 Model
Authors: 
  John C. Williams, Jianjin Xu, Zhongju Lu, Aleksandra Klimas,
   Christina M. Ambrosi, & Emilia Entcheva
Special thanks to Matthew Epstein & Keith Arora-Williams.

Describes: 
  Current from ChR2 variant H134R under voltage-clamp conditions
   based on experimental data (Cardiac Cell Engineering Laboratory, 
   Stony Brook University) with voltage-, irradiance-, and 
   temperature-dependence.

Code maintained by: John C. Williams
  Contact: John.Williams.1@StonyBrook.edu for assistance, comments, or
    just to let us know you're using this code!

Cardiac Optogenetics and Optical Imaging Lab
  Department of Biomedical Engineering, Stony Brook University
  P.I.  Emilia Entcheva, PhD



Simulation parameters:

tend:		Simulation end time
temperate: 	Simulation temperature, typically 22C
V:		Clamp voltage



Stimulus parameters:

opt.interval:	ms, interval between optical stimuli
opt.delay:	ms, delay before first stimulus
opt.dur:	ms, stimulus duration
opt.irradiance:	mW/mm2, stimulus irradiance
opt.number:	number of stimuli
opt.lambda:	nm, wavelength
(Note: This model is designed for stimuli at or around 470nm)
